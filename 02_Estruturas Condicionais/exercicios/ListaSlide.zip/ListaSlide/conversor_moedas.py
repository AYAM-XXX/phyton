dinheiro = float(input("insira o valor:"))
print(" digite \n1-Dólar\n2-Euro\n3-Libra")
escolha = int(input("insira o numero: "))
if(escolha == 1):
    print()
elif(escolha == 2):
    print("")
elif (escolha == 3):


else:
    print("valor incorreto")




# Conversor de Moedas Dinâmico: Crie um menu onde o usuário escolhe a moeda de destino para converter
# $R\$\,100.00$: 1-Dólar, 2-Euro, 3-Libra. Faça o cálculo e imprima o valor convertido usando a estrutura
# estudada